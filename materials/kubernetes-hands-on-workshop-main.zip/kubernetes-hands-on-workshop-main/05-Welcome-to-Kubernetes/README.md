Welcome to Kubernetes
================================

[Welcome to Kubernetes](https://robrich.org/slides/kubernetes-test-drive/#/) is an online presentation.
