Secrets in Containers
=====================

[Secrets in Containers](https://robrich.org/slides/docker-secrets/#/) is an online presentation.
