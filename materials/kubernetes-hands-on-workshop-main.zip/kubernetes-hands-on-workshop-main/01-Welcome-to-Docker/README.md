Welcome to Docker
=================

[Welcome to Docker](https://robrich.org/slides/welcome-to-docker/#/) is an online presentation.
