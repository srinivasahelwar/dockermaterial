Secrets in Containers
=====================

[Docker Secrets](https://robrich.org/slides/docker-secrets/#/) is an online presentation.
