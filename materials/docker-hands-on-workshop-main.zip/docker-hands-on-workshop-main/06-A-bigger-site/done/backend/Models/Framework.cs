﻿namespace backend.Models
{
    public class Framework
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Votes { get; set; }
    }
}
