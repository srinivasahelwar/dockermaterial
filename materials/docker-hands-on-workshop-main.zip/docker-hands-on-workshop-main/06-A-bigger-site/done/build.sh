cd backend
docker build --tag backend:0.1 .
cd ../frontend
docker build --tag frontend:0.1 .
cd ..
