Welcome to Docker
=================

Play with [Docker Swarm](http://training.play-with-docker.com/swarm-mode-intro/) on training.play-with-docker.com.
