Welcome to Docker
=================

[Software Architecture for the Cloud](https://robrich.org/slides/software-architecture-for-the-cloud/#/) is an online presentation.
